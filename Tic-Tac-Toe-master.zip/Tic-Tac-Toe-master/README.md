# Tic-Tac-Toe
A simple graphical Tic-Tac-Toe game in python.
Import the graphics.py in the same directory as of TicTacToe.py and run the file using the command
python3 TicTacToe.py
